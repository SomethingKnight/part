# Widgets

```eval_rst

.. toctree::
   :maxdepth: 1

   obj
   arc
   animimg
   bar
   btn
   btnmatrix
   calendar
   chart
   colorwheel
   canvas
   checkbox
   dropdown
   img
   imgbtn
   keyboard
   label
   led
   line
   list
   menu
   meter
   msgbox
   roller
   slider
   span
   spinbox
   spinner
   switch
   table
   tabview
   textarea
   tileview
   win

```


